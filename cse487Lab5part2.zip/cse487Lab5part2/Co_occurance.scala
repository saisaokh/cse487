import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.ml.feature.NGram
import org.apache.spark.sql.SparkSession

val input =  sc.textFile("vergil.aeneid.tess")
  val words = input.map(line => line.split(">\t").toList)
  val normalized = words.filter(k=>k.size>1).map(x=> {
      val chapno = x.apply(0)
      val data = x.apply(1)
      val datawithI = data.replace('j','i')
      val datawithU = datawithI.replace('v','u')
      (chapno, datawithU)
  })

  val input2 =  sc.textFile("lucan.bellum_civile.part.1.tess")
  val words2 = input.map(line => line.split(">\t").toList)
  val normalized2 = words.filter(k=>k.size>1).map(x=> {
    val chapno = x.apply(0)
    val data = x.apply(1)
    val datawithI = data.replace('j','i')
    val datawithU = datawithI.replace('v','u')
    (chapno, datawithU)
  })

  val inputcsv =  sc.textFile("new_lemmatizer.csv")
  val trycsv = inputcsv.map(x=>{
    val line  = x.split(",").map(_.trim).toList
    val word = line.head
    val standard = line.drop(1)
    (word,standard)
  }).collect().toMap


  val finalDoc1 = normalized.zipWithIndex.map{case(x,i)=>{
    val line = x._2.split(" ").map(_.trim).toList
    val normal = line.flatMap(y=>{
      val word = y.replaceAll("""([?,'.!:]|\b\p{IsLetter}{1,2}\b)\s*""", "")
      val standard = trycsv.get(word)
      standard
    }).filter(x=>(x!=null))
    (normal,x._1)
  }}
  val ngramed = finalDoc1.flatMap(x=>{
    val listOfWords = x._1
    val tempList = listOfWords.map(y=>(y,"Doc1"+x._2+'>'))
    tempList
  })


  val finalDoc2 = normalized2.zipWithIndex.map{case(x,i)=>{
    val line = x._2.split(" ").map(_.trim).toList
    val normal = line.flatMap(y=>{
      val word = y.replaceAll("""([?,'.!:]|\b\p{IsLetter}{1,2}\b)\s*""", "")
      val standard = trycsv.get(word)
      standard
    }).filter(x=>(x!=null))
    (normal,x._1)
  }}
  val ngramed2 = finalDoc2.flatMap(x=>{
    val listOfWords = x._1
    val tempList = listOfWords.map(y=>(y,"Doc2"+x._2+'>'))
    tempList
  })


  ngramed.filter(x=> x!=null).foreach(x=>{
    if(x._1.size==2)
    println(x)
  })

  ngramed2.filter(x=> x!=null).foreach(x=>{
    if(x._1.size==2)
    println(x)
  })

